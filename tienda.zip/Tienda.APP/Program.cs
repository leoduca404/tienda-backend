﻿using Application.Interfaces;
using Application.Interfaces.Ventas;
using Application.UseCase;
using Application.UseCase.Ventas;
using Infraestructure.Command;
using Infraestructure.Data;
using Infraestructure.Querys;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Tienda.APP;
using Tienda.APP.Clientes.Services;
using Tienda.APP.Helpers;
using Tienda.APP.Ventas.Services;

//1. Create a service collection for DI
ServiceCollection services = new ServiceCollection();

IConfiguration configuration = new ConfigurationBuilder()
    .SetBasePath(Directory.GetParent(AppContext.BaseDirectory).FullName)
    .AddJsonFile("appsettings.json")
    .Build();

//3. Add the configuration to the service collection.
services.AddSingleton<IConfiguration>(configuration);

services.AddSingleton<IProductoServices,ProductoServices>();
services.AddSingleton<IProductoQuery, ProductoQuery>();
services.AddSingleton<IProductoCommand, ProductoCommand>();

services.AddSingleton<IClienteServices,ClienteServices>();
services.AddSingleton<IClienteQuery, ClienteQuery>();
services.AddSingleton<IClienteCommand, ClienteCommand>();
services.AddSingleton<RegistrarClienteServices>();

services.AddSingleton<IReporteServices, ReporteServices>();
services.AddSingleton<IVentasQuery, VentasQuery>();

services.AddSingleton<ICarritoServices,CarritoServices>();
services.AddSingleton<ICarritoQuery, CarritoQuery>();
services.AddSingleton<ICarritoCommand, CarritoCommand>();
services.AddSingleton<RegistrarVentasServices>();

services.AddSingleton<Menu>();
services.AddSingleton<LogicaPantalla>();
services.AddSingleton<ReportesServices>();


services.AddDbContext<TiendaContext>(options =>
{
    var connectionString = configuration.GetSection("ConnectionString").Value;
    options.UseSqlServer(connectionString);
}, ServiceLifetime.Singleton);

var serviceProvider = services.BuildServiceProvider();

var menu = serviceProvider.GetService<Menu>();
if (menu != null) {await menu.InicializarMenuPrincipal(); }